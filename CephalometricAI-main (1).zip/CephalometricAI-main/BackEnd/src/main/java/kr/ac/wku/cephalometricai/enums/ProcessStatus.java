package kr.ac.wku.cephalometricai.enums;

public enum ProcessStatus {
    PROCESSING,
    COMPLETED;
}
