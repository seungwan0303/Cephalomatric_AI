package kr.ac.wku.cephalometricai.exception;

public class AlreadyExistUserIdException extends Exception{
    public AlreadyExistUserIdException(String message){
        super(message);
    }
}
